<?php
session_start();

// === LOGIN SECTION ===
$login_username = "admin";
$login_password = "123";

if (isset($_POST['login'])) {
    if ($_POST['username'] == $login_username && $_POST['password'] == $login_password) {
        $_SESSION['login'] = true;
        header("Location: booking_futsal.php");
        exit();
    } else {
        $error = "Username atau Password salah!";
    }
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: booking_futsal.php");
    exit();
}

if (!isset($_SESSION['login']) && !isset($_POST['login'])) {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .login-box { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.2); width: 300px; }
        input { width: 100%; padding: 8px; margin-top: 10px; }
        button { padding: 8px 12px; width: 100%; margin-top: 10px; background: #007BFF; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .error { color: red; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="login-box">
        <h2>Login Admin</h2>
        <form method="post">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Login</button>
            <?php if (isset($error)) echo "<div class='error'>$error</div>"; ?>
        </form>
    </div>
</body>
</html>
<?php
exit();
}

// === CONNECT DATABASE ===
$conn = mysqli_connect("localhost", "root", "", "futsal_sederhana");
if (!$conn) die("Koneksi gagal: " . mysqli_connect_error());

// === CRUD MEMBER ===
// Create
if (isset($_POST['add_member'])) {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    mysqli_query($conn, "INSERT INTO member (name, phone) VALUES ('$name', '$phone')");
    header("Location: booking_futsal.php?section=member");
}

// Update
if (isset($_POST['update_member'])) {
    $id = $_POST['member_id'];
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    mysqli_query($conn, "UPDATE member SET name='$name', phone='$phone' WHERE member_id=$id");
    header("Location: booking_futsal.php?section=member");
}

// Delete
if (isset($_GET['delete_member'])) {
    $id = $_GET['delete_member'];
    mysqli_query($conn, "DELETE FROM member WHERE member_id=$id");
    header("Location: booking_futsal.php?section=member");
}

$edit_member = null;
if (isset($_GET['edit_member'])) {
    $id = $_GET['edit_member'];
    $edit_member = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM member WHERE member_id=$id"));
}

// === CRUD BOOKING ===
if (isset($_POST['add_booking'])) {
    $member_id = $_POST['member_id'];
    $field_id = $_POST['field_id'];
    $date = $_POST['booking_date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];
    $price = $_POST['total_price'];
    mysqli_query($conn, "INSERT INTO booking (member_id, field_id, booking_date, start_time, end_time, total_price) VALUES ('$member_id','$field_id','$date','$start','$end','$price')");
    header("Location: booking_futsal.php");
}

if (isset($_POST['update_booking'])) {
    $id = $_POST['booking_id'];
    $member_id = $_POST['member_id'];
    $field_id = $_POST['field_id'];
    $date = $_POST['booking_date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];
    $price = $_POST['total_price'];
    mysqli_query($conn, "UPDATE booking SET member_id='$member_id', field_id='$field_id', booking_date='$date', start_time='$start', end_time='$end', total_price='$price' WHERE booking_id=$id");
    header("Location: booking_futsal.php");
}

if (isset($_GET['delete_booking'])) {
    $id = $_GET['delete_booking'];
    mysqli_query($conn, "DELETE FROM booking WHERE booking_id=$id");
    header("Location: booking_futsal.php");
}

$edit_booking = null;
if (isset($_GET['edit_booking'])) {
    $id = $_GET['edit_booking'];
    $edit_booking = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM booking WHERE booking_id=$id"));
}

// Fetch Data
$members = mysqli_query($conn, "SELECT * FROM member");
$fields = mysqli_query($conn, "SELECT * FROM field");
$bookings = mysqli_query($conn, "SELECT booking.*, member.name AS member_name, field.field_name FROM booking JOIN member ON booking.member_id=member.member_id JOIN field ON booking.field_id=field.field_id");
$member_list = mysqli_query($conn, "SELECT * FROM member");

// Check section (booking / member)
$section = isset($_GET['section']) ? $_GET['section'] : 'booking';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Booking Futsal - Admin Panel</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f9f9f9; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #fff; }
        th, td { padding: 8px; border: 1px solid #ccc; text-align: center; }
        form { background: #fff; padding: 15px; margin-top: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        input, select { padding: 5px; margin: 5px 0; width: 100%; }
        button { padding: 8px 12px; margin-top: 10px; cursor: pointer; background: #28a745; color: white; border: none; border-radius: 4px; }
        a { text-decoration: none; color: #007BFF; margin-right: 10px; }
        .logout { float: right; background: #dc3545; padding: 5px 10px; color: white; border-radius: 4px; }
        nav { margin-bottom: 20px; }
    </style>
</head>
<body>

<h2>Booking Futsal - Admin Panel</h2>
<a href="?logout=true" class="logout">Logout</a>

<nav>
    <a href="?section=booking">Booking</a>
    <a href="?section=member">Member</a>
</nav>

<?php if ($section == 'member') { ?>

<!-- === MEMBER SECTION === -->
<h3>Daftar Member</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Nama</th>
        <th>No HP</th>
        <th>Aksi</th>
    </tr>
    <?php while($m = mysqli_fetch_assoc($member_list)) { ?>
    <tr>
        <td><?= $m['member_id'] ?></td>
        <td><?= $m['name'] ?></td>
        <td><?= $m['phone'] ?></td>
        <td>
            <a href="?section=member&edit_member=<?= $m['member_id'] ?>">Edit</a> |
            <a href="?section=member&delete_member=<?= $m['member_id'] ?>" onclick="return confirm('Hapus member ini?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>

<form method="post">
    <h3><?= $edit_member ? "Edit Member" : "Tambah Member Baru" ?></h3>
    <input type="hidden" name="member_id" value="<?= $edit_member['member_id'] ?? '' ?>">
    <label>Nama:</label>
    <input type="text" name="name" value="<?= $edit_member['name'] ?? '' ?>" required>

    <label>No HP:</label>
    <input type="text" name="phone" value="<?= $edit_member['phone'] ?? '' ?>" required>

    <button type="submit" name="<?= $edit_member ? 'update_member' : 'add_member' ?>">
        <?= $edit_member ? 'Update' : 'Tambah' ?>
    </button>
</form>

<?php } else { ?>

<!-- === BOOKING SECTION === -->
<h3>Daftar Booking</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Member</th>
        <th>Lapangan</th>
        <th>Tanggal</th>
        <th>Mulai</th>
        <th>Selesai</th>
        <th>Harga</th>
        <th>Aksi</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($bookings)) { ?>
    <tr>
        <td><?= $row['booking_id'] ?></td>
        <td><?= $row['member_name'] ?></td>
        <td><?= $row['field_name'] ?></td>
        <td><?= $row['booking_date'] ?></td>
        <td><?= $row['start_time'] ?></td>
        <td><?= $row['end_time'] ?></td>
        <td><?= $row['total_price'] ?></td>
        <td>
            <a href="?edit_booking=<?= $row['booking_id'] ?>">Edit</a> |
            <a href="?delete_booking=<?= $row['booking_id'] ?>" onclick="return confirm('Hapus booking ini?')">Hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>

<form method="post">
    <h3><?= $edit_booking ? "Edit Booking" : "Tambah Booking Baru" ?></h3>
    <input type="hidden" name="booking_id" value="<?= $edit_booking['booking_id'] ?? '' ?>">

    <label>Member:</label>
    <select name="member_id" required>
        <option value="">--Pilih Member--</option>
        <?php mysqli_data_seek($members, 0); while($m = mysqli_fetch_assoc($members)) { ?>
        <option value="<?= $m['member_id'] ?>" <?= (isset($edit_booking) && $edit_booking['member_id'] == $m['member_id']) ? 'selected' : '' ?>><?= $m['name'] ?></option>
        <?php } ?>
    </select>

    <label>Lapangan:</label>
    <select name="field_id" required>
        <option value="">--Pilih Lapangan--</option>
        <?php mysqli_data_seek($fields, 0); while($f = mysqli_fetch_assoc($fields)) { ?>
        <option value="<?= $f['field_id'] ?>" <?= (isset($edit_booking) && $edit_booking['field_id'] == $f['field_id']) ? 'selected' : '' ?>><?= $f['field_name'] ?></option>
        <?php } ?>
    </select>

    <label>Tanggal Booking:</label>
    <input type="date" name="booking_date" value="<?= $edit_booking['booking_date'] ?? '' ?>" required>

    <label>Jam Mulai:</label>
    <input type="time" name="start_time" value="<?= $edit_booking['start_time'] ?? '' ?>" required>

    <label>Jam Selesai:</label>
    <input type="time" name="end_time" value="<?= $edit_booking['end_time'] ?? '' ?>" required>

    <label>Total Harga:</label>
    <input type="number" step="0.01" name="total_price" value="<?= $edit_booking['total_price'] ?? '' ?>" required>

    <button type="submit" name="<?= $edit_booking ? 'update_booking' : 'add_booking' ?>">
        <?= $edit_booking ? 'Update' : 'Tambah' ?>
    </button>
</form>

<?php } ?>

</body>
</html>
